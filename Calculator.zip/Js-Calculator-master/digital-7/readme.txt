True Type Fonts: DIGITAL-7 version 1.02


EULA
-==-
The fonts Digital-7 is freeware for home using.


DESCRIPTION
-=========-

This font created specially for program Calculator-7 (download shareware version: http://www.styleseven.com/ and use 7 days fo free).

The program Calculator-7 offers you the following possibilities:
* calculate using seven operator: addition, subtraction, multiply, divide, percent, square root, 1 divide to X;
* set decimal position (0, 2, 3, float) and round type (up, mathematical, down);
* customize an appearance of work window: scale, fonts for digital panel and buttons, background color;
* customize an appearance of number in digital panel: leading zero for decimal, thousand separator, decimal separator, digit grouping;
* calculate total from clipboard (copy data to clipboard from table or text and press one button).


Files in digital-7_font.zip:
       	readme.txt     			this file;
        digital-7.ttf    		digital-7 regular font;
	digital-7 (italic).ttf 		digital-7 italic font;
	digital-7 (mono).ttf    	digital-7 mono font;
	digital-7 (mono italic).ttf    	digital-7 mono font.

Please visit http://www.styleseven.com/ for download our other products as freeware as shareware.
We will welcome any useful suggestions and comments; please send them to ms-7@styleseven.com


FREEWARE USE (NOTES)
-=================-
Also you may: 
 * Use the font in freeware software (credit needed);
 * Use the font for your education process.


COMMERCIAL OR BUSINESS USE
-========================-

You can buy font for commercial use here ($24.95): http://store.esellerate.net/s.aspx?s=STR0331655240
You may:
 * Include the font to your installation;
 * Use one license up to 100 computers in your office.
Please contact us for any questions.


WHAT IS NEW?
-==========-

 Version 1.01 April 05 2009
 --------------------------
  * Change Typeface name for fonts "Digital-7 (mono)" and "Digital-7 (italic)" (now available all fonts for select in application, for example Word Pad).
  * Corrected symbol ':'.

 Version 1.01 April 07 2011
 --------------------------
   * Embedding is allowed.

 Version 1.1 June 07 2013
 --------------------------
   * Mono Italic font is added.


AUTHOR
-====-

Sizenko Alexander
Style-7
http://www.styleseven.com
Created: October 7 2008